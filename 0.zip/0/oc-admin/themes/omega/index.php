<?php
/*
Theme Name: Omega Admin Theme
Theme URI: https://osclasspoint.com/osclass-themes/oc-admin/omega-free-oc-admin-osclass-theme_i102
Theme Type: oc-admin
Description: Clean and intuitive template for osclass oc-admin
Version: 3.2.0
Author: MB Themes
Author URI: https://osclasspoint.com
Widgets: header,footer
Theme update URI: omega-oc-admin-theme
Product Key: kbUtlUi37pjcT4Do0OI1
*/
?>